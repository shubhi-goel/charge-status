battery-charge
===================================

A simple web-app which tells the status of the system's battery with percentage left and whether the system is charging or not.
